package com.clakestudio.pc.dzisja.blankfragment

import android.arch.lifecycle.ViewModel
import javax.inject.Inject

class BlankViewModel @Inject constructor() : ViewModel() {
}