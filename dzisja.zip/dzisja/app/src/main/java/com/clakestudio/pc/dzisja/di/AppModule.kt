package com.clakestudio.pc.dzisja.di

import dagger.Module

@Module(includes = [ViewModelModule::class])
class AppModule {

    /**
     * Here are out retrofit, database and other "components" created
     *
     * */


}