package com.clakestudio.pc.dzisja.di

interface Injectable {
}